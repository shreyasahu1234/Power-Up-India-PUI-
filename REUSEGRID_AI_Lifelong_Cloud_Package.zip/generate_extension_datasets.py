"""
REUSEGRID AI -- Additive Component Dataset Generator
Generates 800 component-level records, recovered inventory pool, reconstruction targets,
and degradation feedback datasets, exporting to CSV and an Excel workbook.
"""

import os
import random
import numpy as np
import pandas as pd

# Set deterministic seed for reproducibility
np.random.seed(42)
random.seed(42)

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(CURRENT_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

# Load existing 500 batteries for donor mapping
bats_df = pd.read_csv(os.path.join(DATA_DIR, "batteries.csv"))
donor_ids = bats_df["Battery_ID"].tolist()

# ==============================================================================
# 1. GENERATE 800 COMPONENT RECORDS
# ==============================================================================
component_types = [
    ("Lithium-Ion Cylindrical Cell (18650 3.7V / 2.6Ah)", "Cell_18650", 3.7, 2.6, 18, 55, 120),
    ("LiFePO4 Prismatic Cell (3.2V / 50Ah)", "Cell_LFP_50Ah", 3.2, 50.0, 1.8, 1200, 2400),
    ("LiFePO4 Prismatic Cell (3.2V / 20Ah)", "Cell_LFP_20Ah", 3.2, 20.0, 3.5, 650, 1400),
    ("NMC Pouch Cell (3.7V / 15Ah)", "Cell_NMC_15Ah", 3.7, 15.0, 4.2, 500, 1100),
    ("Power Tool High-Drain Cell (18650 3.6V / 2.0Ah)", "Cell_PowerTool", 3.6, 2.0, 12, 90, 180),
    ("Modular BMS Protection Board (4S 40A Balancer)", "BMS_4S", 14.8, 0.0, 15, 450, 950),
    ("Modular BMS Protection Board (16S 100A Smart CAN)", "BMS_16S", 48.0, 0.0, 8, 1800, 3800),
    ("Modular BMS Protection Board (10S 30A e-Bike)", "BMS_10S", 36.0, 0.0, 20, 600, 1300),
    ("Modular BMS Protection Board (3S 25A Compact)", "BMS_3S", 11.1, 0.0, 25, 300, 700),
    ("NTC Thermistor Temperature Sensor Probe (10k)", "Sensor_NTC", 0.0, 0.0, 0, 40, 150),
    ("Heavy-Duty XT60 / XT90 Connector Harness", "Connector_XT", 0.0, 0.0, 0.5, 80, 220),
    ("Nickel-Plated Copper Busbar Interconnect Link", "Busbar_Cu", 0.0, 0.0, 0.2, 50, 140),
    ("Modular Extruded Aluminum Enclosure & Frame", "Casing_Alu", 0.0, 0.0, 0, 350, 900),
    ("Flame-Retardant Cell Spacer & Insulation Shield", "Spacer_Matrix", 0.0, 0.0, 0, 120, 300)
]

# Probabilities for component types
type_weights = [0.28, 0.12, 0.10, 0.10, 0.10, 0.06, 0.04, 0.04, 0.04, 0.04, 0.03, 0.02, 0.02, 0.01]

components_list = []
total_records = 800

for i in range(1, total_records + 1):
    comp_id = f"COMP_{i:04d}"
    donor_id = random.choice(donor_ids)
    donor_row = bats_df[bats_df["Battery_ID"] == donor_id].iloc[0]
    
    # Pick component template
    idx = np.random.choice(len(component_types), p=type_weights)
    c_name, c_sub, nom_v, nom_ah, base_ir, salvage_cost, new_cost = component_types[idx]
    
    is_cell = "Cell" in c_name
    is_bms = "BMS" in c_name
    is_sensor = "Sensor" in c_name
    is_casing = "Casing" in c_name
    is_conn = "Connector" in c_name
    
    # Cycles derived with variance from donor pack
    donor_cycles = int(donor_row.get("Historical_Cycles", 500))
    comp_cycles = max(20, int(donor_cycles + np.random.normal(0, 60)))
    
    # Base health calculation
    cycle_deg = comp_cycles * 0.022
    rand_noise = np.random.normal(0, 3.0)
    
    if is_cell:
        base_soh = np.clip(100.0 - cycle_deg + rand_noise, 40.0, 98.5)
        # Measured capacity
        meas_ah = round(nom_ah * (base_soh / 100.0), 3)
        # IR growth with degradation
        meas_ir = round(base_ir * (1.0 + (100.0 - base_soh) * 0.018 + np.random.normal(0, 0.05)), 2)
        meas_v = round(nom_v + np.random.normal(0.08, 0.04) if base_soh > 60 else nom_v - 0.4, 3)
        meas_v = max(2.1, meas_v)
    elif is_bms:
        # BMS health relates to port/switching integrity
        base_soh = np.clip(98.0 - (comp_cycles * 0.008) + rand_noise, 30.0, 99.0)
        meas_ah = 0.0
        meas_ir = round(base_ir + np.random.normal(0, 2.0), 1)
        meas_v = nom_v
    else:
        base_soh = np.clip(99.0 - (comp_cycles * 0.005) + rand_noise, 50.0, 99.5)
        meas_ah = 0.0
        meas_ir = base_ir
        meas_v = 0.0
        
    base_soh = round(float(base_soh), 1)
    
    # Visual defect simulation
    if base_soh > 85:
        defect = "Pristine (Like New)"
        thermal_stability = "Normal Stability (dt/dt < 0.2 C/min)"
        grade = "Grade A (Premium Reuse, >85% SoH)"
        recovery_status = "Harvested & In Stock"
    elif base_soh > 70:
        defect = random.choice(["Pristine (Like New)", "Minor Surface Scratches", "Cosmetic Enclosure Blemish"])
        thermal_stability = "Normal Stability (dt/dt < 0.4 C/min)"
        grade = "Grade B (Standard Reuse, 70-85% SoH)"
        recovery_status = "Harvested & In Stock"
    elif base_soh > 55:
        defect = random.choice(["Moderate Cycle Wear", "Slight Terminal Oxidation", "Enclosure Hairline Crack"])
        thermal_stability = "Elevated Impedance (Manage C-Rate)"
        grade = "Grade C (Low-Stress Buffer, 55-70% SoH)"
        recovery_status = "Harvested & In Stock"
    else:
        defect = random.choice(["Mechanical Swelling (>4%)", "Electrolyte Trace", "Burnt Trace / Overheated", "Internal Short Risk"])
        thermal_stability = "Thermal Drift Risk (Unsafe)"
        grade = "Reject (Unsafe / Recycling Only)"
        recovery_status = "Quarantined for Recycling"
        
    # Electrochemical binning group for cells (12 bins based on capacity & IR tolerance)
    if is_cell:
        cap_bin = int(min(11, max(0, (meas_ah / max(0.1, nom_ah)) * 12)))
        bin_group = f"Group_BIN_{cap_bin + 1:02d}"
    else:
        bin_group = "N/A (Non-Cell)"
        
    # Economic and environmental metrics
    econ_salvage = salvage_cost if "Reject" not in grade else 15
    econ_savings = max(0, new_cost - econ_salvage)
    co2_kg = round(econ_savings * 0.045 + (meas_ah * 0.85 if is_cell else 0.5), 2)
    
    # Compatibility flags
    if "Reject" in grade:
        comp_flag = "Disqualified (Recycle Only)"
    elif "Grade A" in grade and is_cell:
        comp_flag = "High-Drain & Traction Compatible"
    elif "Grade B" in grade and is_cell:
        comp_flag = "Stationary ESS & Solar Microgrid Compatible"
    elif "Grade C" in grade and is_cell:
        comp_flag = "Low C-Rate IoT & Lantern Buffer Compatible"
    else:
        comp_flag = "Standard Modular Hardware Compatible"

    components_list.append({
        "Component_ID": comp_id,
        "Source_Battery_ID": donor_id,
        "Component_Type": c_name,
        "Sub_Category": c_sub,
        "Nominal_Voltage_V": nom_v,
        "Measured_Voltage_V": meas_v,
        "Rated_Capacity_Ah": nom_ah,
        "Measured_Capacity_Ah": meas_ah,
        "Internal_Resistance_mOhm": meas_ir,
        "Historical_Cycles": comp_cycles,
        "Estimated_Health_SoH_Percent": base_soh,
        "Visual_Defect_Inspection": defect,
        "Thermal_Stability_Index": thermal_stability,
        "Component_Grade": grade,
        "Recovery_Status": recovery_status,
        "Estimated_Salvage_Value_INR": econ_salvage,
        "Replacement_Cost_New_INR": new_cost,
        "Economic_Savings_INR": econ_savings,
        "CO2_Emissions_Avoided_kg": co2_kg,
        "Electrochemical_Matching_Group": bin_group,
        "Compatibility_Flags": comp_flag
    })

df_components = pd.DataFrame(components_list)
df_components.to_csv(os.path.join(DATA_DIR, "component_dataset.csv"), index=False)
print(f"[+] Created data/component_dataset.csv with {len(df_components)} records.")


# ==============================================================================
# 2. GENERATE RECOVERED COMPONENT INVENTORY (AGGREGATE POOL)
# ==============================================================================
inv_summary = df_components.groupby(["Component_Type", "Component_Grade"]).agg(
    Total_Units=("Component_ID", "count"),
    Avg_SoH_Percent=("Estimated_Health_SoH_Percent", "mean"),
    Avg_Capacity_Ah=("Measured_Capacity_Ah", "mean"),
    Avg_IR_mOhm=("Internal_Resistance_mOhm", "mean"),
    Total_Economic_Value_INR=("Estimated_Salvage_Value_INR", "sum"),
    Total_CO2_Avoided_kg=("CO2_Emissions_Avoided_kg", "sum")
).reset_index()

inv_summary["Avg_SoH_Percent"] = inv_summary["Avg_SoH_Percent"].round(1)
inv_summary["Avg_Capacity_Ah"] = inv_summary["Avg_Capacity_Ah"].round(2)
inv_summary["Avg_IR_mOhm"] = inv_summary["Avg_IR_mOhm"].round(2)
inv_summary["Total_CO2_Avoided_kg"] = inv_summary["Total_CO2_Avoided_kg"].round(1)

inv_summary.to_csv(os.path.join(DATA_DIR, "battery_component_inventory.csv"), index=False)
print(f"[+] Created data/battery_component_inventory.csv with {len(inv_summary)} inventory bin summaries.")


# ==============================================================================
# 3. GENERATE RECONSTRUCTION TARGETS DATASET
# ==============================================================================
reconstruction_targets = [
    {
        "Target_ID": "TGT_01",
        "Target_Application_Name": "48V 50Ah Community Solar ESS Bank",
        "Target_Voltage_Nominal_V": 51.2,
        "Target_Capacity_Ah": 50.0,
        "Target_Energy_Wh": 2560.0,
        "Required_Cell_Chemistry": "LiFePO4 Prismatic Cell (3.2V / 50Ah)",
        "Required_Series_Parallel": "16S1P",
        "Required_Cell_Count": 16,
        "Required_BMS_Type": "Modular BMS Protection Board (16S 100A Smart CAN)",
        "Required_Connector_Type": "Heavy-Duty XT60 / XT90 Connector Harness",
        "Min_Cell_SoH_Percent": 82.0,
        "Max_Cell_Capacity_Delta_Percent": 4.5,
        "Max_Cell_IR_Delta_mOhm": 0.6,
        "BMS_Current_Rating_A": 100.0,
        "Target_Application_Criticality": 4,
        "Max_Target_Budget_INR": 24000,
        "Reconstruction_Target_Description": "Scalable 2.56 kWh village microgrid energy storage unit constructed by matching Grade A 50Ah LFP prismatic cells with smart 16S CAN bus balancing."
    },
    {
        "Target_ID": "TGT_02",
        "Target_Application_Name": "24V 20Ah Agri-Drone / Drip Irrigation Battery",
        "Target_Voltage_Nominal_V": 25.9,
        "Target_Capacity_Ah": 20.0,
        "Target_Energy_Wh": 518.0,
        "Required_Cell_Chemistry": "NMC Pouch Cell (3.7V / 15Ah)",
        "Required_Series_Parallel": "7S2P",
        "Required_Cell_Count": 14,
        "Required_BMS_Type": "Modular BMS Protection Board (10S 30A e-Bike)",
        "Required_Connector_Type": "Heavy-Duty XT60 / XT90 Connector Harness",
        "Min_Cell_SoH_Percent": 78.0,
        "Max_Cell_Capacity_Delta_Percent": 4.5,
        "Max_Cell_IR_Delta_mOhm": 1.5,
        "BMS_Current_Rating_A": 35.0,
        "Target_Application_Criticality": 3,
        "Max_Target_Budget_INR": 8500,
        "Reconstruction_Target_Description": "High-energy-density modular pack for agricultural automation, water valve actuation, and precision spray drones."
    },
    {
        "Target_ID": "TGT_03",
        "Target_Application_Name": "12V 40Ah Rural Telecom Rack-Mount Buffer",
        "Target_Voltage_Nominal_V": 12.8,
        "Target_Capacity_Ah": 40.0,
        "Target_Energy_Wh": 512.0,
        "Required_Cell_Chemistry": "LiFePO4 Prismatic Cell (3.2V / 20Ah)",
        "Required_Series_Parallel": "4S2P",
        "Required_Cell_Count": 8,
        "Required_BMS_Type": "Modular BMS Protection Board (4S 40A Balancer)",
        "Required_Connector_Type": "Heavy-Duty XT60 / XT90 Connector Harness",
        "Min_Cell_SoH_Percent": 75.0,
        "Max_Cell_Capacity_Delta_Percent": 3.0,
        "Max_Cell_IR_Delta_mOhm": 1.0,
        "BMS_Current_Rating_A": 40.0,
        "Target_Application_Criticality": 4,
        "Max_Target_Budget_INR": 6200,
        "Reconstruction_Target_Description": "Standard 19-inch rack DC backup module for cellular transceiver stations using matched Grade B+ LFP cells."
    },
    {
        "Target_ID": "TGT_04",
        "Target_Application_Name": "36V 15.6Ah Light e-Rickshaw / E-Bike Range Extender",
        "Target_Voltage_Nominal_V": 37.0,
        "Target_Capacity_Ah": 15.6,
        "Target_Energy_Wh": 577.2,
        "Required_Cell_Chemistry": "Lithium-Ion Cylindrical Cell (18650 3.7V / 2.6Ah)",
        "Required_Series_Parallel": "10S6P",
        "Required_Cell_Count": 60,
        "Required_BMS_Type": "Modular BMS Protection Board (10S 30A e-Bike)",
        "Required_Connector_Type": "Heavy-Duty XT60 / XT90 Connector Harness",
        "Min_Cell_SoH_Percent": 80.0,
        "Max_Cell_Capacity_Delta_Percent": 5.5,
        "Max_Cell_IR_Delta_mOhm": 3.0,
        "BMS_Current_Rating_A": 30.0,
        "Target_Application_Criticality": 3,
        "Max_Target_Budget_INR": 7500,
        "Reconstruction_Target_Description": "High-reliability e-mobility battery assembled from 60 tightly binned Grade A 18650 cells with integrated active thermal sensor matrix."
    },
    {
        "Target_ID": "TGT_05",
        "Target_Application_Name": "12V 10.4Ah Off-Grid School LED Lantern & Digital Lab Hub",
        "Target_Voltage_Nominal_V": 11.1,
        "Target_Capacity_Ah": 10.4,
        "Target_Energy_Wh": 115.4,
        "Required_Cell_Chemistry": "Lithium-Ion Cylindrical Cell (18650 3.7V / 2.6Ah)",
        "Required_Series_Parallel": "3S4P",
        "Required_Cell_Count": 12,
        "Required_BMS_Type": "Modular BMS Protection Board (3S 25A Compact)",
        "Required_Connector_Type": "Heavy-Duty XT60 / XT90 Connector Harness",
        "Min_Cell_SoH_Percent": 70.0,
        "Max_Cell_Capacity_Delta_Percent": 3.0,
        "Max_Cell_IR_Delta_mOhm": 4.0,
        "BMS_Current_Rating_A": 20.0,
        "Target_Application_Criticality": 3,
        "Max_Target_Budget_INR": 2100,
        "Reconstruction_Target_Description": "Low-cost educational lighting and tablet charging hub built with Grade B 18650 cells and robust aluminum casing."
    },
    {
        "Target_ID": "TGT_06",
        "Target_Application_Name": "24V 8Ah Emergency Medical Cooler & Vaccine Box",
        "Target_Voltage_Nominal_V": 25.6,
        "Target_Capacity_Ah": 8.0,
        "Target_Energy_Wh": 204.8,
        "Required_Cell_Chemistry": "Power Tool High-Drain Cell (18650 3.6V / 2.0Ah)",
        "Required_Series_Parallel": "7S4P",
        "Required_Cell_Count": 28,
        "Required_BMS_Type": "Modular BMS Protection Board (10S 30A e-Bike)",
        "Required_Connector_Type": "Heavy-Duty XT60 / XT90 Connector Harness",
        "Min_Cell_SoH_Percent": 80.0,
        "Max_Cell_Capacity_Delta_Percent": 6.5,
        "Max_Cell_IR_Delta_mOhm": 2.5,
        "BMS_Current_Rating_A": 30.0,
        "Target_Application_Criticality": 5,
        "Max_Target_Budget_INR": 4200,
        "Reconstruction_Target_Description": "High-reliability thermal management pack for maintaining refrigerated vaccine supplies in remote clinic environments."
    }
]

df_targets = pd.DataFrame(reconstruction_targets)
df_targets.to_csv(os.path.join(DATA_DIR, "reconstruction_targets.csv"), index=False)
print(f"[+] Created data/reconstruction_targets.csv with {len(df_targets)} target reconstruction applications.")


# ==============================================================================
# 4. GENERATE DEGRADATION HISTORY & FEEDBACK DATASET
# ==============================================================================
feedback_records = []
rebuilt_pack_names = ["REBUILT_TGT01_001", "REBUILT_TGT02_001", "REBUILT_TGT03_001", "REBUILT_TGT04_001", "REBUILT_TGT05_001", "REBUILT_TGT06_001"]

for p_name in rebuilt_pack_names:
    cycle_points = [0, 50, 100, 150, 200, 250, 300, 350, 400, 450, 500]
    initial_cap_ret = 100.0
    initial_ir_growth = 0.0
    
    for c in cycle_points:
        retention = round(max(60.0, initial_cap_ret - (c * 0.038) + np.random.normal(0, 0.4)), 1)
        ir_growth = round(initial_ir_growth + (c * 0.065) + np.random.normal(0, 0.5), 1)
        delta_v = round(8.0 + (c * 0.04) + np.random.normal(0, 1.2), 1)
        temp_delta = round(1.2 + (c * 0.008) + np.random.normal(0, 0.2), 2)
        bms_eff = round(max(85.0, 99.2 - (c * 0.015) + np.random.normal(0, 0.3)), 1)
        
        if c < 300:
            state = "Stable Linear Degradation"
        elif c < 450:
            state = "Moderate Aging (Balancing Active)"
        else:
            state = "Secondary Retirement Review Required"
            
        feedback_records.append({
            "Rebuilt_Pack_ID": p_name,
            "Operating_Cycle": c,
            "Capacity_Retention_Percent": retention,
            "Internal_Resistance_Growth_Percent": ir_growth,
            "Cell_Delta_V_Imbalance_mV": delta_v,
            "Thermal_Operating_Delta_C": temp_delta,
            "BMS_Balancing_Efficiency_Percent": bms_eff,
            "Degradation_State": state,
            "Feedback_Recommendation": "Optimal Performance" if c < 350 else "Recalibrate Cell String 2"
        })

df_feedback = pd.DataFrame(feedback_records)
df_feedback.to_csv(os.path.join(DATA_DIR, "degradation_history.csv"), index=False)
print(f"[+] Created data/degradation_history.csv with {len(df_feedback)} degradation feedback records.")


# ==============================================================================
# 5. EXPORT INTEGRATED EXCEL WORKBOOK
# ==============================================================================
excel_path = os.path.join(DATA_DIR, "REUSEGRID_AI_Component_Reconstruction_Extension.xlsx")
with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
    df_components.to_excel(writer, sheet_name="Component_Dataset_800", index=False)
    inv_summary.to_excel(writer, sheet_name="Recovered_Inventory", index=False)
    df_targets.to_excel(writer, sheet_name="Reconstruction_Targets", index=False)
    df_feedback.to_excel(writer, sheet_name="Degradation_Feedback", index=False)

print(f"[+] Exported comprehensive Excel workbook: {excel_path}")
