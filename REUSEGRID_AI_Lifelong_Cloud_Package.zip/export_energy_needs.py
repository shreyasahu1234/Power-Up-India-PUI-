import pandas as pd

en = pd.read_csv('data/energy_needs.csv')
bat = pd.read_csv('data/batteries.csv')

for c in ['Nominal_Voltage_V', 'State_of_Health_SoH_Percent', 'Effective_Available_Energy_Wh',
          'Internal_Resistance_mOhm', 'Historical_Cycles']:
    bat[c] = pd.to_numeric(bat[c], errors='coerce')

counts = []
for _, app in en.iterrows():
    acc_elig = [e.strip() for e in str(app['accepted_eligibility']).split(';')]
    mask = (
        (bat['Nominal_Voltage_V'] >= app['min_voltage_v']) &
        (bat['Nominal_Voltage_V'] <= app['max_voltage_v']) &
        (bat['State_of_Health_SoH_Percent'] >= app['min_health']) &
        (bat['Effective_Available_Energy_Wh'] >= app['min_energy_wh'] * 0.70) &
        (bat['Internal_Resistance_mOhm'] <= app['max_ir_mohm']) &
        (bat['Historical_Cycles'] <= app['max_cycles'])
    )
    elig_mask = bat['Pool_Eligibility_Status'].apply(
        lambda e: any(ae in str(e) for ae in acc_elig)
    )
    counts.append(int((mask & elig_mask).sum()))

en['compatible_batteries_in_500'] = counts

with pd.ExcelWriter('data/energy_needs.xlsx', engine='openpyxl') as writer:
    en.to_excel(writer, sheet_name='Application_Profiles', index=False)

    summary = en[['application', 'criticality', 'min_health', 'min_energy_wh',
                   'min_voltage_v', 'max_voltage_v', 'power_req_w', 'backup_hours',
                   'allocation_quota', 'compatible_batteries_in_500']].copy()
    summary.columns = ['Application', 'Criticality (1-5)', 'Min Health %',
                        'Min Energy Wh', 'Min Voltage V', 'Max Voltage V',
                        'Power Req W', 'Backup Hours', 'Quota', 'Eligible from 500 Pool']
    summary.to_excel(writer, sheet_name='Summary', index=False)

print('energy_needs.xlsx saved.')
print()
print(en[['application', 'criticality', 'min_voltage_v', 'max_voltage_v',
          'min_energy_wh', 'allocation_quota', 'compatible_batteries_in_500']].to_string(index=False))
