from backend.hardware_bridge import HardwareBridge
from backend.similarity_matcher import BatterySimilarityMatcher

bridge = HardwareBridge()
matcher = BatterySimilarityMatcher()

print("Hardware Bridge Mode:", bridge.mode)
for ch in ["CH1", "CH2", "CH3"]:
    t = bridge.read_live_telemetry(ch)
    res = matcher.find_most_similar_case(t, top_k=3)
    b = res["enriched_battery"]
    print("-" * 70)
    print(f"Physical Channel: {ch} | Live Telemetry: {t['measured_voltage']}V, {t['operating_temperature']}C, {t['temp_rise_rate']}C/min, {t['internal_resistance_mOhm']} mOhm")
    print(f"Matched Dataset Case: {res['best_match_id']} (Similarity: {res['similarity_score_pct']}%)")
    print(f"Inferred Chemistry/Type: {b['Battery_Type']} ({b['Pack_Configuration']})")
    print(f"Inferred History: {b['Historical_Cycles']} cycles, {b['Estimated_Age_Years']} yrs")
    print(f"Inferred Diagnosed Issue: {b['Primary_Diagnosed_Issue']}")
    print(f"Top 3 Nearest Neighbors:")
    for n in res["top_k_matches"]:
        print(f"   Rank {n['rank']}: {n['battery_id']} - {n['battery_type']} ({n['similarity_score_pct']}% match, {n['historical_cycles']} cyc)")
