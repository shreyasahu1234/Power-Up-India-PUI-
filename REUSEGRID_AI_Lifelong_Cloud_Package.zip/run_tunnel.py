"""
REUSEGRID AI -- Cloudflare High-Speed Public Tunnel Daemon
Keeps Cloudflare Quick Tunnel connected continuously to 127.0.0.1:8501.
"""
import subprocess
import re
import time
import os
import sys

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
URL_FILE = os.path.join(CURRENT_DIR, "data", "public_url.txt")
CLOUDFLARED_BIN = os.path.join(CURRENT_DIR, "cloudflared.exe")

def start_tunnel():
    print(f"[REUSEGRID AI] Starting persistent Cloudflare Tunnel to 127.0.0.1:8501...")
    cmd = [
        CLOUDFLARED_BIN,
        "tunnel",
        "--url", "http://127.0.0.1:8501"
    ]
    
    while True:
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )
            
            for line in iter(proc.stdout.readline, ''):
                line_str = line.strip()
                if line_str:
                    print(line_str)
                    match = re.search(r'https://[a-zA-Z0-9-]+\.trycloudflare\.com', line_str)
                    if match:
                        url = match.group(0)
                        print(f"\n{'='*75}")
                        print(f"  ⚡ REUSEGRID AI LIVE CLOUDFLARE PUBLIC URL:")
                        print(f"  👉 {url}")
                        print(f"{'='*75}\n")
                        with open(URL_FILE, "w") as f:
                            f.write(url)
            
            proc.wait()
            print("[REUSEGRID AI] Tunnel disconnected. Reconnecting in 2 seconds...")
            time.sleep(2)
        except Exception as e:
            print(f"[REUSEGRID AI] Tunnel error: {e}. Retrying in 3s...")
            time.sleep(3)

if __name__ == "__main__":
    start_tunnel()
